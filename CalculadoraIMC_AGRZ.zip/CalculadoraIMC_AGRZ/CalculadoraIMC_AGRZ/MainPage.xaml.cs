﻿using CalculadoraIMC_AGRZ.ViewModels;

namespace CalculadoraIMC_AGRZ
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            BindingContext = new Procedimiento();
        }
    }
}
