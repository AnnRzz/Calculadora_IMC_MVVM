﻿
using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Input;

namespace CalculadoraIMC_AGRZ.ViewModels
{
    public class Procedimiento : INotifyPropertyChanged
    {
        private string altura;
        private string peso;
        private string imc;
        private string resultado;

        public event PropertyChangedEventHandler PropertyChanged;

        public string Altura
        {
            get { return altura; }
            set
            {
                altura = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Altura)));
            }
        }

        public string Peso
        {
            get { return peso; }
            set
            {
                peso = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Peso)));
            }
        }

        public string IMC
        {
            get { return imc; }
            set
            {
                imc = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IMC)));
            }
        }

        public string Resultado
        {
            get { return resultado; }
            set
            {
                resultado = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Resultado)));
            }
        }

        public ICommand CalcularCommand { get; }

        public Procedimiento()
        {
            CalcularCommand = new Command(Calcular);
        }

        private void Calcular()
        {
            if (string.IsNullOrWhiteSpace(Altura) ||
                string.IsNullOrWhiteSpace(Peso))
            {
                Resultado = "Ingresa la altura y el peso.";
                IMC = "";
                return;
            }

            if (!double.TryParse(Altura, NumberStyles.Number,
                CultureInfo.CurrentCulture, out double alturaValor) ||
                !double.TryParse(Peso, NumberStyles.Number,
                CultureInfo.CurrentCulture, out double pesoValor))
            {
                Resultado = "Ingresa valores validos.";
                IMC = "";
                return;
            }

            if (alturaValor <= 0 || pesoValor <= 0)
            {
                Resultado = "La altura y el peso deben ser mayores a cero";
                IMC = "";
                return;
            }

            double calculo = pesoValor / (alturaValor * alturaValor);

            IMC = calculo.ToString("F2");

            if (calculo < 18.5)
            {
                Resultado = "Tienes bajo peso.";
            }
            else if (calculo < 25)
            {
                Resultado = "Tienes un peso normal.";
            }
            else if (calculo < 30)
            {
                Resultado = "Tienes sobrepeso.";
            }
            else
            {
                Resultado = "Tienes obesidad.";
            }
        }
    }
}
