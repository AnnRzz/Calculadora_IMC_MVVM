﻿namespace CalculadoraIMC_AGRZ
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
        }
    }
}
